#ifndef _H_MYSPYSDK
#define _H_MYSPYSDK
#define SPYVER 0x001

#include <windows.h>
#define MMSG    int
#define MPARAM  DWORD

//MySpy plugin callback function
typedef int (*MySpyPluginProc)
  (MMSG msg,MPARAM wParam,MPARAM lParam);

//Application information structure
typedef struct APPINFO
{
  char Name[20];
  char Version[10];
  char Author[20];
  char Info[200];
} AppInfo,*PAppInfo;

//MySPY Message Declare
#define MM_NULL         0x0000
#define MM_INIT         0x0001
#define MM_DESTROY      0x0002
#define MM_ADDPAGE      0x0003
#define MM_GETPAGEICON  0x0004
#define MM_GETAPPINFO   0x0005
#define MM_ADDMENU      0x0006
#define MM_MENUINVOKE		0x0007

//MySpy Retrue Result Declare
#define MR_HANDLED      1
#define MR_BADCALL      -1
#define MR_NOHANDLE     0


#endif
