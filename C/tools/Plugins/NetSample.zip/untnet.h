//---------------------------------------------------------------------------

#ifndef untnetH
#define untnetH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class Tfrmnet : public TForm
{
__published:	// IDE-managed Components
  TTreeView *treeWnd;
  TStatusBar *sbmain;
  void __fastcall treeWndClick(TObject *Sender);
private:	// User declarations
  HWND m_Parent;
public:		// User declarations
  __fastcall Tfrmnet(TComponent *Owner,HWND hwnd);
  void __fastcall GetChildWnd(HWND);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfrmnet *frmnet;
//---------------------------------------------------------------------------
#endif
