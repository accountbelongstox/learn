//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "..\MyspySDK.h"
#include <string.h>
#include <stdio.h>
#pragma argsused

#include "untnet.h"
#include "untabout.h"
HINSTANCE DllInst=NULL; //DLL instance
int LoadCount=0; //Load count
HWND MySpyWnd=NULL; //HWND of MySpy's main window

char* appName="Plugin Sample"; //Plugin name
TForm* frmmain=NULL; //MySpy's frmmain pointer
TApplication *savedApp = NULL; //Plugin Application pointer backup

int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{

  switch(reason)
  {
    case DLL_PROCESS_ATTACH:
      LoadCount++;
      DllInst=hinst;
      //place your init code here
      break;
    case DLL_PROCESS_DETACH:
      LoadCount--;
      DllInst=NULL;
      //place your destroy code here
      break;
  }
  return 1;
}

//---------------------------------------------------------------------------
extern "C" __declspec(dllexport)
int __stdcall MMPlugin(MMSG msg,MPARAM wParam,MPARAM lParam)
{
  switch(msg)
  {
    case MM_INIT:
      //place your init code here
      {
      frmmain=(TForm*)wParam;
      MySpyWnd=(HWND)lParam;
      savedApp=Application;
      //Get application of MySpy and backup this application;

      return MR_HANDLED;
      }
    case MM_DESTROY:
      //place your destroy code here
      Application=savedApp;
      MySpyWnd=NULL;
      break;
    case MM_ADDMENU:
      {
        char* mnustr=(char*)lParam;
        memcpy(mnustr,"Get Child",9);
        return MR_HANDLED;
      }
		case MM_ADDPAGE:
			{
        int id=wParam;
        if(id==0)
        {
				  char* pagestr=(char*)lParam;
				  memcpy(pagestr,"NetSample",9);
				  return MR_HANDLED;
        }
			}
    case MM_PLACEPAGE:
      {
        if(wParam==0)
        {
        /*HWND parent=(HWND)lParam;
        frm->ParentWindow=parent;
        frm->Top=0;
        frm->Left=0;
        frm->Show();*/
        }
        break;
      }
    case MM_MENUINVOKE:
      {
      PWndInfo wi=(PWndInfo)lParam;
      HWND capWnd=wi->CapturedWnd;
      Application->Handle=MySpyWnd;
      int id=wParam;
        switch(id)
        {
        case 0:
          Tfrmnet* frm=new Tfrmnet(Application,MySpyWnd);
          frm->GetChildWnd(capWnd);
          frm->ShowModal();
          delete frm;
          break;
        }
      break;
      }
    case MM_GETINFO:
    	{
    	PAppInfo ai=(PAppInfo)lParam;
    	strcpy(ai->Name,appName);
    	strcpy(ai->Version,"1.0");
    	strcpy(ai->Author,"Aweay");
      strcpy(ai->Intro,"����һ��Plugin������.");
    	return MR_HANDLED;
    	}
    case MM_ABOUT:
      {
      HWND hwnd=(HWND)lParam;
      Application->Handle=hwnd;
      Tfrmabout* frm=new Tfrmabout(Application);
      frm->ShowModal();
      delete frm;
      break;
      }
  }
  return MR_BADCALL;
}


