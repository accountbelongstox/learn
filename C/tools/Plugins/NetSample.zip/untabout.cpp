//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "untabout.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tfrmabout *frmabout;
//---------------------------------------------------------------------------
__fastcall Tfrmabout::Tfrmabout(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tfrmabout::Button1Click(TObject *Sender)
{
  Close();  
}
//---------------------------------------------------------------------------
