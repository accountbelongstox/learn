//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "..\MyspySDK.h"
#include "untnet.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tfrmnet *frmnet;
int WndCount=0;
String GetWndClass(HWND hwnd);
HWND parentwnd=NULL;

BOOL CALLBACK EnumChildProc(HWND hwnd,LPARAM lParam)
{

  WndCount++;
  TTreeNode* parentnode=(TTreeNode*)lParam;
  frmnet->treeWnd->Items->AddChildObject(parentnode,GetWndClass(hwnd),hwnd);
  return true;
}


__fastcall Tfrmnet::Tfrmnet(TComponent *Owner,HWND hwnd)
  :TForm(Owner)
{
  m_Parent=hwnd;
  frmnet=this;
}



void __fastcall Tfrmnet::GetChildWnd(HWND hwnd)
{
  //TODO: Add your source code here
  TTreeNode* node=treeWnd->Items->AddObject(NULL,GetWndClass(hwnd),hwnd);
  EnumChildWindows(hwnd,(WNDENUMPROC)EnumChildProc,(LPARAM)node);
  sbmain->SimpleText=String(WndCount)+" Child Window[s]";
}


String GetWndClass(HWND hwnd)
{
  //TODO: Add your source code here
  char buf[255];
  GetClassName(hwnd,buf,255);
  return String(buf);
}



void __fastcall Tfrmnet::treeWndClick(TObject *Sender)
{
  if(treeWnd->Selected)
  {
    HWND hwnd=treeWnd->Selected->Data;
    SendMessage(m_Parent,MM_SETWINDOW,0,(LPARAM)hwnd);
  }
}
//---------------------------------------------------------------------------

