//---------------------------------------------------------------------------

#ifndef untaboutH
#define untaboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class Tfrmabout : public TForm
{
__published:	// IDE-managed Components
  TLabel *Label1;
  TButton *Button1;
  void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall Tfrmabout(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfrmabout *frmabout;
//---------------------------------------------------------------------------
#endif
